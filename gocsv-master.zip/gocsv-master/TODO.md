# TODO

## Roadmap

- [ ] Implement `format` subcommand to output with different delimiters, etc. This might replace the `tsv` subcommand.
- [ ] Support `-` as a filename specifying `stdin` like csvkit does.

## Maybe

- [ ] Add subcommand autocomplete (for `zshell` at least).